var greet = 'Hello!';
var greet = 'Hola!'; 

console.log(greet);

var english = { 
    greetings: { 
        basic: 'Hello!' 
    } 
};

var spanish = {};

spanish.greet = 'Hola!';

console.log(english);