var 
    // first name of the person
    firstname, 
    
    // last name of the person
    lastname, 
    
    // the language
    // can be 'en' or 'es'
    language;

var person = {
    // the first name
    firstname: 'John',
    
    // the last name
    // (always required)
    lastname: 'Doe'
}

console.log(person);