function getPerson() {
 
    return {
        firstname: 'Tony'
    }
    
}

console.log(getPerson());